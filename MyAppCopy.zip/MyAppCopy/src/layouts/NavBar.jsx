import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { UserContext } from "..";

const NavBar = () => {
  const { role } = useContext(UserContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to log out?");
    if (confirmLogout) {
      localStorage.removeItem("token");
      localStorage.removeItem("userId");
      localStorage.removeItem("userName");
      localStorage.removeItem("role");
      navigate("/");
    }
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          <i className="fas fa-home" style={{ color: '#ff007f', fontSize: '1.5em' }}></i>
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            {role === "ROLE_ADMIN" && (
              <li className="nav-item me-3">
                <Link className="nav-link" to="/add-movie" style={{ color: 'black', textDecoration: 'none' }}>
                  <strong style={{ transition: 'color 0.3s' }} onMouseOver={(e) => e.target.style.color = '#ff007f'} onMouseOut={(e) => e.target.style.color = 'black'}>Add Movie</strong>
                </Link>
              </li>
            )}
            <li className="nav-item me-3">
              <Link className="nav-link" to="/view-order" style={{ color: 'black', textDecoration: 'none' }}>
                <strong style={{ transition: 'color 0.3s' }} onMouseOver={(e) => e.target.style.color = '#ff007f'} onMouseOut={(e) => e.target.style.color = 'black'}>View Order</strong>
              </Link>
            </li>
            <li className="nav-item">
              <span className="nav-link" style={{ color: 'black', cursor: 'pointer', textDecoration: 'none' }} onClick={handleLogout}>
                <strong style={{ transition: 'color 0.3s' }} onMouseOver={(e) => e.target.style.color = '#ff007f'} onMouseOut={(e) => e.target.style.color = 'black'}>Logout</strong>
              </span>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;