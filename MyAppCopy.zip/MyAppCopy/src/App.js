import { BrowserRouter,Route, Routes } from "react-router-dom";
import Login from "./components/user/Login";
import Register from "./components/user/Register";
import AllMovies from "./components/movie/AllMovies";
import LandingPage from "./landing-page/LandingPage";
import ViewOrder from "./components/order/ViewOrder";
import AddMovie from "./components/movie/AddMovie";
import PlaceOrder from "./components/order/PlaceOrder";
import UpdateMovie from "./components/movie/UpdateMovie";
import PageNotFound from "./landing-page/PageNotFound";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/register' element={<Register/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        <Route path="/" element={<LandingPage/>}></Route>
        <Route path='/movies' element={<AllMovies />}></Route>
        <Route path='/add-movie' element={<AddMovie />}></Route>
        <Route path='/view-order' element={<ViewOrder />}></Route>
        <Route path="/order/:movieId" element={<PlaceOrder />} />
        <Route path="/update-movie/:movieId" element={<UpdateMovie />} />
        <Route path="*" element={<PageNotFound/>}/>
      </Routes> 
      </BrowserRouter>
    </div>
  );
}

export default App;
