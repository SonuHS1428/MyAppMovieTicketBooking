import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      <h2>PAGE NOT FOUND</h2>
    </div>
  )
}

export default PageNotFound
