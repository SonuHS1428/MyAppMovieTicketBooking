import React from "react";
import { useNavigate } from "react-router-dom";
import "./LandingPage.css"; // Import CSS

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-page d-flex flex-column min-vh-100">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg">
        <div className="container">
          <div className="d-flex ms-auto">
            <button className="btn btn-login me-2" onClick={() => navigate("/login")}>
              Login
            </button>
            <button className="btn btn-register" onClick={() => navigate("/register")}>
              Register
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container d-flex flex-grow-1 align-items-center">
        <div className="row align-items-center">
          {/* Text Section */}
          <div className="col-md-6">
            <h1>MOVIE TICKETS BOOKING APP</h1>
            <p className="landing-p">
              Enjoy seamless movie ticket booking with us. Choose your favorite movies and reserve your seats now!
            </p>
          </div>

          {/* Image Section */}
          <div className="col-md-6 text-center">
            <img 
              src="https://th.bing.com/th/id/R.f362aeab7bccfbb6f6cd8fc7a894213a?rik=V7HnboVgOWUq6Q&riu=http%3a%2f%2fwww.pngmart.com%2ffiles%2f5%2fMovie-PNG-Image.png&ehk=%2fumio4t09y9STFf20eSdXl2dIS1ZDaGJrTSDSZqsZZY%3d&risl=&pid=ImgRaw&r=0"
              alt="Movie Illustration"
              className="img-fluid"
              style={{ maxWidth: "400px" }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;






//else {
      //   // If the cinema hall was partially updated, display the message and introduce a delay
      //   if (updateData.msg.includes("partially updated")) {
      //     setErrorMessage(updateData.msg);
      //     setSuccessMessage("");

      //     // Introduce a delay before placing the order
      //     setTimeout(async () => {
      //       try {
      //         const orderResponse = await axios.post(`http://localhost:1414/orders/api/v1/order/${userId}/${movieId}`, {
      //           seat: updateData.data,
      //         }, {
      //           headers: {
      //             Authorization: `Bearer ${token}`,
      //           },
      //         });

      //         console.log(orderResponse);
      //         setSuccessMessage("Order placed successfully");
      //         setErrorMessage("");

      //         setTimeout(() => {
      //           navigate("/view-order");
      //         }, 2000);
      //       } catch (error) {
      //         setErrorMessage(error.response?.data?.message || "Failed to place order");
      //         setSuccessMessage("");
      //       }
      //     }, 2000); // Delay of 4 seconds
        //} 