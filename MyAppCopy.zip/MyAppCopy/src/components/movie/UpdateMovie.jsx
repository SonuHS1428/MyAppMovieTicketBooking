// UpdateMovie.js
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const UpdateMovie = () => {
  const { movieId } = useParams();
  const [formData, setFormData] = useState({
    movieName: "",
    movieImage: "",
    language: "",
    money: "",
    movieSession: "",
    seats: "",
  });
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(`http://localhost:1414/movies/getById/${movieId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const movie = response.data;

        // Fetch available seats from the cinema halls API
        const availableSeatsResponse = await axios.get(`http://localhost:1414/cinemahalls/api/v1/getavailableseats/${movieId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const availableSeats = availableSeatsResponse.data.availableSeats;

        setFormData({
          movieName: movie.movieName,
          movieImage: movie.movieImage,
          language: movie.language,
          money: movie.money,
          movieSession: movie.movieSession,
          seats: availableSeats.join(", "), // Use available seats
        });
      } catch (error) {
        console.error("Error fetching movie:", error);
      }
    };
    fetchMovie();
  }, [movieId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.put(
        "http://localhost:1414/movies/update",
        {
          ...formData,
          movieId: Number(movieId),
          seats: formData.seats.split(",").map(Number),
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setSuccessMessage("Movie updated successfully");
      setErrorMessage("");

      setTimeout(() => {
        navigate("/movies");
      }, 2000);
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to update movie");
      setSuccessMessage("");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Update Movie</h2>

      {successMessage && (
        <div className="alert alert-success text-center">{successMessage}</div>
      )}
      {errorMessage && (
        <div className="alert alert-danger text-center">{errorMessage}</div>
      )}

      <div className="d-flex justify-content-center">
        <div className="w-50" style={{ maxWidth: "400px" }}>
          <form onSubmit={handleSubmit} className="p-3 border rounded">
            <input
              type="text"
              name="movieName"
              placeholder="Movie Name"
              className="form-control mb-2"
              onChange={handleChange}
              value={formData.movieName}
              required
            />
            <input
              type="text"
              name="movieImage"
              placeholder="Movie Image"
              className="form-control mb-2"
              value={formData.movieImage}
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="language"
              placeholder="Language"
              className="form-control mb-2"
              onChange={handleChange}
              value={formData.language}
              required
            />
            <input
              type="number"
              name="money"
              placeholder="Price"
              className="form-control mb-2"
              onChange={handleChange}
              value={formData.money}
              required
            />
            <input
              type="text"
              name="movieSession"
              placeholder="Session"
              className="form-control mb-2"
              onChange={handleChange}
              value={formData.movieSession}
              required
            />
            <input
              type="text"
              name="seats"
              placeholder="Seats (comma-separated)"
              className="form-control mb-2"
              onChange={handleChange}
              value={formData.seats}
              // value={availableSeats}
              required
            />
            <button
              type="submit"
              className="btn w-100"
              style={{ backgroundColor: "#ff007f", color: "#fff" }}
            >
              Update Movie
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UpdateMovie;