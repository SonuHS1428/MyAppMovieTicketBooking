import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddMovie = () => {
  const [formData, setFormData] = useState({
    movieName: "",
    language: "",
    money: "",
    movieSession: "",
    movieImage:"",
    seats: "",
  });
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      const response = await axios.post("http://localhost:1414/movies/addmovie", {
        ...formData,
        seats: formData.seats.split(",").map(Number), // Convert seats to an array of numbers
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setSuccessMessage(response.data);
      setErrorMessage("");

      setTimeout(() => {
        navigate("/movies");
      }, 2000);
    } catch (error) {
      setErrorMessage(error.response.data.message || "Failed to add movie");
      setSuccessMessage("");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Add Movie</h2>

      {successMessage && (
        <div className="alert alert-success text-center">{successMessage}</div>
      )}
      {errorMessage && (
        <div className="alert alert-danger text-center">{errorMessage}</div>
      )}

      <div className="d-flex justify-content-center">
        <div className="w-50" style={{ maxWidth: "400px" }}>
          <form onSubmit={handleSubmit} className="p-3 border rounded">
            <input
              type="text"
              name="movieName"
              placeholder="Movie Name"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="movieImage"
              placeholder="Movie Image"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="language"
              placeholder="Language"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="number"
              name="money"
              placeholder="Price"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="movieSession"
              placeholder="Session"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="seats"
              placeholder="Seats (comma-separated)"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn w-100" style={{ backgroundColor: '#ff007f', color: '#fff' }}>Add Movie</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddMovie;
