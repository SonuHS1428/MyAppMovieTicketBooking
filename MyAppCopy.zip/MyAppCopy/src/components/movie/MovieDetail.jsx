import React from 'react'

const MovieDetail = () => {
  return (
    <div>
      
    </div>
  )
}

export default MovieDetail
