import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { UserContext } from "../..";
import NavBar from "../../layouts/NavBar";

const AllMovies = () => {
  const [movies, setMovies] = useState([]);
  const navigate = useNavigate();
  const { userId, userName, role } = useContext(UserContext);
  console.log("in all movies", userId);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get("http://localhost:1414/movies/getAll", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log(response.data);
        if (response.data) {
          setMovies(response.data);
        }
      } catch (error) {
        console.error("Error fetching movies:", error);
      }
    };
    fetchMovies();
  }, []);

  console.log("Fetched Movies:", movies);

  const handleUpdate = (movieId) => {
    navigate(`/update-movie/${movieId}`);
  };

  const handleDelete = async (movieId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this movie?");
    if (confirmDelete) {
      try {
        const token = localStorage.getItem("token");
        await axios.delete(`http://localhost:1414/movies/deleteById/${movieId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setMovies(movies.filter((movie) => movie.movieId !== movieId));
      } catch (error) {
        console.error("Error deleting movie:", error);
      }
    }
  };

  const handleOrder = (movie) => {
    navigate(`/order/${movie.movieId}`, { state: { movie } });
  };

  return (
    <>
      <NavBar />
      <div className="container mt-5">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h3>
            Hello, <span style={{ color: '#ff007f' }}>{userName}</span> ! Glad to have you here.
          </h3>
        </div>
        {movies && movies.length > 0 ? (
          <div className="row">
            {movies.map((movie) => (
              <div key={movie.movieId} className="col-md-4 mb-4">
                <div className="card h-100 shadow-sm">
                  <img
                    src={movie.movieImage}
                    alt={movie.movieName}
                    className="card-img-top"
                    style={{ height: '300px', objectFit: 'cover' }}
                  />
                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title" style={{ color: '#ff007f' }}><strong>{movie.movieName}</strong></h5>
                    <p className="card-text"><strong>Language:</strong> {movie.language}</p>
                    <p className="card-text"><strong>Price:</strong> Rs.{movie.money}</p>
                    <p className="card-text"><strong>Session:</strong> {movie.movieSession}</p>
                    <div className="d-flex justify-content-between">
                      <button className="btn btn w-33 me-1" style={{ backgroundColor: '#ff007f', color: '#fff' }} onClick={() => handleOrder(movie)}>View details</button>
                      {role === "ROLE_ADMIN" && (
                        <>
                          <button className="btn btn w-33 me-1" style={{ backgroundColor: '#007bff', color: '#fff' }} onClick={() => handleUpdate(movie.movieId)}>Update</button>
                          <button className="btn btn w-33" style={{ backgroundColor: '#dc3545', color: '#fff' }} onClick={() => handleDelete(movie.movieId)}>Delete</button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center">No movies available.</p>
        )}
      </div>
    </>
  );
};

export default AllMovies;
