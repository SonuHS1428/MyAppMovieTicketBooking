import React, { useContext, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { UserContext } from "../..";

const PlaceOrder = () => {
  const location = useLocation();
  const { movie } = location.state;
  const [seats, setSeats] = useState("");
  const [availableSeats, setAvailableSeats] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();
  const { userId } = useContext(UserContext);
  console.log("User ID from context:", userId);

  useEffect(() => {
    const fetchAvailableSeats = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(`http://localhost:1414/cinemahalls/api/v1/getavailableseats/${movie.movieId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log("available seats", response.data);
        if (response.data && response.data.availableSeats.length > 0) {
          setAvailableSeats(response.data.availableSeats);
        } else {
          // If the API doesn't return available seats, fall back to the movie seats
          setAvailableSeats(movie.seats);
        }
      } catch (error) {
        console.error("Error fetching available seats:", error);
        // If there's an error, fall back to the movie seats
        setAvailableSeats(movie.seats);
      }
    };
    fetchAvailableSeats();
  }, [movie.movieId, movie.seats]);

  const handleSeatClick = (seat) => {
    setSeats((prevSeats) => {
      const seatsArray = prevSeats ? prevSeats.split(",").map(Number) : [];
      if (seatsArray.includes(seat)) {
        return seatsArray.filter((s) => s !== seat).join(",");
      } else {
        return [...seatsArray, seat].join(",");
      }
    });
  };

  const handleChange = (e) => {
    setSeats(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const selectedSeats = seats.split(",").map(Number);

    // Check if all selected seats are valid
    const invalidSeats = selectedSeats.filter(seat => !availableSeats.includes(seat));
    if (invalidSeats.length > 0) {
      setErrorMessage(`${invalidSeats.join(", ")} seats are not available. Please select other seats.`);
      setSuccessMessage("");
      return;
    }

    try {
      const token = localStorage.getItem("token");

      // Call the update API with the user input seats
      const updateResponse = await axios.put(`http://localhost:1414/cinemahalls/api/v1/movie/update/${movie.movieId}`, {
        updatedSeats: selectedSeats,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Handle the response from the update API
      const updateData = updateResponse.data;

      if (updateData.data.length === 0) {
        // If the data array is empty, display the message and do not place the order
        setErrorMessage("Sorry all these seats are already booked, please select other seats");
        setSuccessMessage("");
      } else {
        // Update the available seats locally
        setAvailableSeats((prevSeats) => prevSeats.filter(seat => !selectedSeats.includes(seat)));

        // Place the order using the updated seats data
        const orderResponse = await axios.post(`http://localhost:1414/orders/api/v1/order/${userId}/${movie.movieId}`, {
          seat: updateData.data,
        }, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        console.log(orderResponse);
        setSuccessMessage("Seats booked successfully");
        setErrorMessage("");

        setTimeout(() => {
          navigate("/view-order");
        }, 2000);
      }
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to place order");
      setSuccessMessage("");
    }
  };

  return (
    <div className="container mt-5 position-relative">
      {successMessage && (
        <div className="alert alert-success text-center position-fixed top-0 start-50 translate-middle-x mt-3" style={{ zIndex: 1050 }}>
          {successMessage}
        </div>
      )}
      {errorMessage && (
        <div className="alert alert-danger text-center position-fixed top-0 start-50 translate-middle-x mt-3" style={{ zIndex: 1050 }}>
          {errorMessage}
        </div>
      )}

      <div className="d-flex justify-content-center mt-5">
        <div className="w-100" style={{ maxWidth: "350px" }}>
          <div className="card mb-3 shadow">
            <div className="card-body">
              <img
                src={movie.movieImage}
                alt={movie.movieName}
                className="card-img-top mb-3 rounded"
                style={{ height: '300px', objectFit: 'cover' }}
              />
              <h5 className="card-title" style={{ color: '#ff007f' }}>
                <strong>{movie.movieName}</strong>
              </h5>
              <p>
                <i className="fas fa-star" style={{ color: 'gold', marginRight: '5px' }}></i>
                <span style={{ color: '#ff007f' }}><strong>9.3/10</strong></span> (45.5K Votes)
              </p>
              <p className="card-text"><strong>Theatre:</strong> Orion Avenue Mall,Banasawadi</p>
              <p className="card-text"><strong>Language:</strong> {movie.language}</p>
              <p className="card-text"><strong>Price:</strong> ${movie.money}</p>
              <p className="card-text"><strong>Session:</strong> {movie.movieSession}</p>
              <p className="card-text"><strong>Available Seats:</strong></p>
              {availableSeats.length > 0 ? (
                <div className="d-flex flex-wrap">
                  {availableSeats.map((seat) => (
                    <button
                      key={seat}
                      className={`btn m-1 ${seats.split(",").map(Number).includes(seat) ? "active" : ""}`}
                      style={{ 
                        borderRadius: "50%", 
                        width: "40px", 
                        height: "40px", 
                        display: "flex", 
                        justifyContent: "center", 
                        alignItems: "center", 
                        backgroundColor: seats.split(",").map(Number).includes(seat) ? "#ff007f" : "#fff",
                        color: seats.split(",").map(Number).includes(seat) ? "#fff" : "#000",
                        border: "2px solid #ff007f",
                      }}
                      onClick={() => handleSeatClick(seat)}
                      onMouseEnter={(e) => e.target.style.backgroundColor = "#ff007f"}
                      onMouseLeave={(e) => e.target.style.backgroundColor = seats.split(",").map(Number).includes(seat) ? "#ff007f" : "#fff"}
                    >
                      {seat}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="d-flex flex-wrap">
                  {movie.seats.map((seat) => (
                    <button
                      key={seat}
                      className={`btn m-1 ${seats.split(",").map(Number).includes(seat) ? "active" : ""}`}
                      style={{ 
                        borderRadius: "50%", 
                        width: "40px", 
                        height: "40px", 
                        display: "flex", 
                        justifyContent: "center", 
                        alignItems: "center", 
                        backgroundColor: seats.split(",").map(Number).includes(seat) ? "#ff007f" : "#fff",
                        color: seats.split(",").map(Number).includes(seat) ? "#fff" : "#000",
                        border: "2px solid #ff007f",
                      }}
                      onClick={() => handleSeatClick(seat)}
                      onMouseEnter={(e) => e.target.style.backgroundColor = "#ff007f"}
                      onMouseLeave={(e) => e.target.style.backgroundColor = seats.split(",").map(Number).includes(seat) ? "#ff007f" : "#fff"}
                    >
                      {seat}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <form onSubmit={handleSubmit} className="p-3 border rounded shadow">
            <input
              type="text"
              name="seats"
              placeholder="Seats (comma-separated)"
              className="form-control mb-3"
              value={seats}
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn btn w-100" style={{ backgroundColor: '#ff007f', color: '#fff' }}>Book Seats</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PlaceOrder;
