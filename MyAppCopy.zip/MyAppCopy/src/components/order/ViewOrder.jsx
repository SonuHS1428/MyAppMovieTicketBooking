import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { UserContext } from "../..";

const ViewOrder = () => {
  const [orderDetails, setOrderDetails] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  const { userId } = useContext(UserContext);

  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(`http://localhost:1414/orders/api/v1/order/${userId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log(response.data);
        if (response.data) {
          setOrderDetails(response.data);
        }
      } catch (error) {
        console.error("Error fetching order details:", error);
        setErrorMessage("Failed to fetch order details.");
      }
    };
    if (userId) {
      fetchOrderDetails();
    }
  }, [userId]);

  return (
    <div className="container mt-5">
        <h4 className="text-center mb-4" style={{ color: '#ff007f', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '2px', borderBottom: '2px solid #ff007f', paddingBottom: '10px' }}>
        Your Last Order Details
      </h4>

      {errorMessage && (
        <div className="alert alert-danger text-center">{errorMessage}</div>
      )}

      {orderDetails ? (
        <div className="card shadow-sm mt-3">
          <div className="card-body">
            <p className="card-text"><strong>Order ID:</strong> <span className="text-muted">{orderDetails.orderId}</span></p>
            <p className="card-text">
              <strong>Order Created At:</strong> <span className="text-muted">{new Date(orderDetails.createdAt).toLocaleString()}</span>
            </p>
            <p className="card-text">
              <strong>User ID:</strong> <span className="text-muted">{orderDetails.customerId}</span>
            </p>
            <p className="card-text">
              <strong>Movie ID:</strong> <span className="text-muted">{orderDetails.movieId}</span>
            </p>
            <p className="card-text">
              <strong>Booked Seats:</strong> <span className="text-muted">{orderDetails.seat.join(", ")}</span>
            </p>
          </div>
        </div>
      ) : (
        <p className="text-center">Loading order details...</p>
      )}
    </div>
  );
};

export default ViewOrder;