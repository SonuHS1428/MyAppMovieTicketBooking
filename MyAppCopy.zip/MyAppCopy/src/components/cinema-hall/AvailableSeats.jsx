import React from 'react'

const AvailableSeats = () => {
  return (
    <div>
      
    </div>
  )
}

export default AvailableSeats
