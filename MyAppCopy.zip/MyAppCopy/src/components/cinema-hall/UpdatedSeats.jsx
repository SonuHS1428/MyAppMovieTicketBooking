import React from 'react'

const UpdatedSeats = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdatedSeats
