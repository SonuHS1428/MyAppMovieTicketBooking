import React from 'react'

const UpdatingSeats = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdatingSeats
