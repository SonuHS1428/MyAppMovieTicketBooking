import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { UserContext } from "../..";

const Login = () => {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const { setUserId, setUserName, setRole } = useContext(UserContext);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:1414/users/authenticate", credentials);
      console.log(response);
      setUserId(response.data.userId);
      setUserName(response.data.userName);
      setRole(response.data.role);
      localStorage.setItem("token", response.data.jwttoken);
      localStorage.setItem("userId", response.data.userId); // Persist userId
      localStorage.setItem("userName", response.data.userName); // Persist userName
      localStorage.setItem("role", response.data.role);
      setErrorMessage("");
      navigate("/movies");
    } catch (error) {
      setErrorMessage("Invalid credentials");
    }
  };

  return (
    <div className="container mt-5" style={{ minHeight: "100vh" }}>
      <h2 className="text-center" style={{ color: '#ff007f' }}>Login</h2>

      {errorMessage && (
        <div className="alert alert-danger text-center">{errorMessage}</div>
      )}

      <div className="d-flex justify-content-center">
        <div className="w-50" style={{ maxWidth: "400px" }}>
          <form onSubmit={handleSubmit} className="p-3 border rounded">
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn w-100" style={{ backgroundColor: '#ff007f', color: '#fff' }}>Login</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
