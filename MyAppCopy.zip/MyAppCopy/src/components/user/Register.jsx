import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    surname: "",
    email: "",
    password: "",
    role: "",
  });

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:1414/users/api/v1/register", formData);
      console.log(response);
      setSuccessMessage(response.data);
      setErrorMessage("");

      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (error) {
      setErrorMessage(error.response.data.message || "Registration failed");
      setSuccessMessage("");
    }
  };
  console.log(formData);
  return (
    <div className="container mt-5" style={{ minHeight: "200vh" }}>
      <h2 className="text-center" style={{ color: '#ff007f' }}>Register</h2>

      {successMessage && (
        <div className="alert alert-success text-center">{successMessage}</div>
      )}
      {errorMessage && (
        <div className="alert alert-danger text-center">{errorMessage}</div>
      )}

      <div className="d-flex justify-content-center">
        <div className="w-50" style={{ maxWidth: "400px" }}>
          <form onSubmit={handleSubmit} className="p-3 border rounded">
            <input
              type="text"
              name="name"
              placeholder="Name"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="text"
              name="surname"
              placeholder="Surname"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="form-control mb-2"
              onChange={handleChange}
              required
            />
            <select name="role" className="form-control mb-2" onChange={handleChange} required>
              <option value="">Select Role</option>
              <option value="ROLE_USER">USER</option>
              <option value="ROLE_ADMIN">ADMIN</option>
            </select>
            <button type="submit" className="btn btn w-100" style={{ backgroundColor: '#ff007f', color: '#fff' }}>Register</button>
          </form>
        </div>
      </div>

      <p className="text-center mt-2" style={{ color: "black" }}>
        Already registered? <a href="/login">Login here</a>
      </p>
    </div>
  );
};

export default Register;
