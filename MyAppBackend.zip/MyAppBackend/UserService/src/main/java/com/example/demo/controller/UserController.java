package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LoginRequestDTO;
import com.example.demo.dto.LoginResponseDTO;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import com.example.demo.utils.JwtUtils;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/users")
public class UserController {

    
    @Autowired
    private AuthenticationManager authManager;
    
    @Autowired
    private JwtUtils jwtUtils;
    
    @Autowired
    private UserRepository userRepository;
    
    private final UserService userService;

    // Constructor for dependency injection
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // End point to register a new user
    @PostMapping("/api/v1/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody User newUser) {
        userService.registerUser(newUser);
        return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
    }
    
    @PostMapping("/authenticate")
    public LoginResponseDTO authenticateAndGetToken(@RequestBody LoginRequestDTO user) {
    	
    	Authentication authentication = authManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
    	
    	if(authentication.isAuthenticated()) {
    		
    		User foundUser = userRepository.findByEmail(user.getEmail()).orElse(null);
    		
    		String token = jwtUtils.generateToken(foundUser.getName(), foundUser.getId(), foundUser.getRole());
    		
    		return new LoginResponseDTO(token,foundUser.getName(),foundUser.getId(),foundUser.getRole());
    	}else {
    		throw new UsernameNotFoundException("Invalid User Request!!");
    	}
    }
    
    
    
}
