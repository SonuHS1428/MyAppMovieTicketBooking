package com.example.demo.movies.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import com.example.demo.movies.client.MovieServiceClient;
import com.example.demo.movies.dto.CinemaHallUpdateDTO;
import com.example.demo.movies.dto.MovieDTO;
import com.example.demo.movies.entity.CinemaHall;
import com.example.demo.movies.repository.CinemaHallRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CinemaHallServiceImplTest {

    @Mock
    private CinemaHallRepository cinemaHallRepository;

    @Mock
    private MovieServiceClient movieServiceClient;

    @InjectMocks
    private CinemaHallServiceImpl cinemaHallService;

    private CinemaHall cinemaHall;
    private CinemaHallUpdateDTO updateDTO;
    private MovieDTO movieDTO;

    @BeforeEach
    public void setUp() {
        cinemaHall = new CinemaHall(1L, 1L, "Morning", "10:00 AM", Arrays.asList(1, 2, 3));
        updateDTO = new CinemaHallUpdateDTO(Arrays.asList(2, 4, 5));
        movieDTO = new MovieDTO();
        movieDTO.setMovieId(1);
        movieDTO.setMovieName("Inception");
        movieDTO.setLanguage("English");
        movieDTO.setMoney(250);
        movieDTO.setMovieSession("Morning");
        movieDTO.setSeats(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8));
    }

    @Test
    public void testGetCinemaHallByMovieIdAndSession() {
        when(cinemaHallRepository.findByMovieIdAndMovieSession(1L, "Morning")).thenReturn(Optional.of(cinemaHall));
        Optional<CinemaHall> result = cinemaHallService.getCinemaHallByMovieIdAndSession(1L, "Morning");
        assertTrue(result.isPresent());
        assertEquals(cinemaHall, result.get());
    }

    @Test
    public void testGetAvailableSeats() {
        when(cinemaHallRepository.findByMovieIdAndMovieSession(1L, "Morning")).thenReturn(Optional.of(cinemaHall));
        when(movieServiceClient.getMovieById(1)).thenReturn(movieDTO);

        HashMap<String, Object> result = cinemaHallService.getAvailableSeats(1L, "Morning");
        List<Integer> availableSeats = (List<Integer>) result.get("availableSeats");

        assertEquals(5, availableSeats.size());
        assertTrue(availableSeats.containsAll(Arrays.asList(4, 5, 6, 7, 8)));
    }

    @Test
    public void testGetAvailableSeatsNoCinemaHall() {
        when(cinemaHallRepository.findByMovieIdAndMovieSession(1L, "Morning")).thenReturn(Optional.empty());

        HashMap<String, Object> result = cinemaHallService.getAvailableSeats(1L, "Morning");
        List<Integer> availableSeats = (List<Integer>) result.get("availableSeats");

        assertEquals(0, availableSeats.size());
    }
}
