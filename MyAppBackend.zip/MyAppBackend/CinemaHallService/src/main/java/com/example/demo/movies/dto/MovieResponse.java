package com.example.demo.movies.dto;

import lombok.Data;
import java.util.List;

@Data
public class MovieResponse {
   private String msg;
   private List<Integer> data;
}
