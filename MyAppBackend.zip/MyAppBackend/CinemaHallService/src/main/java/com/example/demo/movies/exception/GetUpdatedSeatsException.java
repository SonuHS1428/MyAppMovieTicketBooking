package com.example.demo.movies.exception;

//Custom exception for when getting updated seats fails
public class GetUpdatedSeatsException extends RuntimeException {
 public GetUpdatedSeatsException(String message) {
     super(message);
 }
}
