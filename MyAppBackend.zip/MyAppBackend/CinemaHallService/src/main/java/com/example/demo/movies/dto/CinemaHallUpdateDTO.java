package com.example.demo.movies.dto;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CinemaHallUpdateDTO {

//    @NotEmpty(message = "Seats are required")
//    private String movieSession;
//    private String orderTime;
    @NotEmpty(message = "Seats are required")
    private List<Integer> updatedSeats;
}
