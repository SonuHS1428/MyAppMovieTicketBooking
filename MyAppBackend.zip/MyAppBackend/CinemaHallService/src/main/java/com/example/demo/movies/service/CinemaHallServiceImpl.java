package com.example.demo.movies.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.movies.client.MovieServiceClient;
import com.example.demo.movies.dto.CinemaHallUpdateDTO;
import com.example.demo.movies.dto.MovieDTO;
import com.example.demo.movies.entity.CinemaHall;
import com.example.demo.movies.exception.*;
import com.example.demo.movies.repository.CinemaHallRepository;

@Service
public class CinemaHallServiceImpl implements CinemaHallService {

    private final CinemaHallRepository cinemaHallRepository;
    private final MovieServiceClient movieServiceClient;

    // Constructor for dependency injection
    public CinemaHallServiceImpl(CinemaHallRepository cinemaHallRepository, MovieServiceClient movieServiceClient) {
        this.cinemaHallRepository = cinemaHallRepository;
        this.movieServiceClient = movieServiceClient;
    }

    /**
     * Retrieves a cinema hall by movie ID and session.
     * 
     * @param movieId      the ID of the movie
     * @param movieSession the session of the movie
     * @return an Optional containing the cinema hall if found, otherwise an empty Optional
     */
    @Override
    public Optional<CinemaHall> getCinemaHallByMovieIdAndSession(Long movieId, String movieSession) {
        return cinemaHallRepository.findByMovieIdAndMovieSession(movieId, movieSession);
    }

    /**
     * Updates the occupied seats for a given movie session.
     * 
     * @param movieId      the ID of the movie
     * @param movieSession the session of the movie
     * @param updateDTO    the DTO containing the updated seats
     * @return a list of already booked seats
     * @throws UpdateOccupiedSeatsException if there is an error while updating the seats
     */
    @Override
    public List<Integer> updateOccupiedSeats(Long movieId, String movieSession, CinemaHallUpdateDTO updateDTO) {
        try {
            List<Integer> alreadyBooked = new ArrayList<>();
            List<Integer> notBooked = new ArrayList<>();
            Optional<CinemaHall> cinemaHallOptional = cinemaHallRepository.findByMovieIdAndMovieSession(movieId, movieSession);
            CinemaHall cinemaHall = cinemaHallOptional.orElseGet(CinemaHall::new);
            cinemaHall.setMovieId(movieId);
            cinemaHall.setMovieSession(movieSession);

            List<Integer> currentBookedSeats = cinemaHall.getUpdatedSeats();
            if (currentBookedSeats == null) {
                currentBookedSeats = new ArrayList<>();
            }

            boolean flag = checkSeats(currentBookedSeats, updateDTO.getUpdatedSeats(), alreadyBooked, notBooked);
            if (updateDTO.getUpdatedSeats() != null) {
                currentBookedSeats.addAll(notBooked);
            }
            cinemaHall.setUpdatedSeats(currentBookedSeats);

            // Use default or predefined value for orderTime
            cinemaHall.setOrderTime("defaultTime");

            cinemaHallRepository.save(cinemaHall);
            return alreadyBooked;
        } catch (Exception e) {
            throw new UpdateOccupiedSeatsException("Failed to update occupied seats: " + e.getMessage());
        }
    }

    /**
     * Retrieves the available seats for a given movie session.
     * 
     * @param movieId      the ID of the movie
     * @param movieSession the session of the movie
     * @return a HashMap containing the available seats and other details
     * @throws GetAvailableSeatsException if there is an error while fetching the available seats
     */
    @Override
    public HashMap<String, Object> getAvailableSeats(Long movieId, String movieSession) {
        try {
            Optional<CinemaHall> cinemaHallOptional = cinemaHallRepository.findByMovieIdAndMovieSession(movieId, movieSession);
            HashMap<String, Object> response = new HashMap<>();

            if (cinemaHallOptional.isPresent()) {
                CinemaHall cinemaHall = cinemaHallOptional.get();
                MovieDTO movie = movieServiceClient.getMovieById(movieId.intValue());
                List<Integer> totalSeats = new ArrayList<>(movie.getSeats());
                List<Integer> availableSeats = new ArrayList<>(totalSeats);
                availableSeats.removeAll(cinemaHall.getUpdatedSeats());
                response.put("availableSeats", availableSeats);
                return response;
            }
            response.put("availableSeats", new ArrayList<>());
            response.put("totalAmount", 0);
            return response;
        } catch (Exception e) {
            throw new GetAvailableSeatsException("Failed to get available seats: " + e.getMessage());
        }
    }

    /**
     * Checks the seats and categorizes them into already booked and not booked.
     * 
     * @param AllSeats      the list of all booked seats
     * @param seats         the list of seats to check
     * @param alreadyBooked the list to store already booked seats
     * @param notBooked     the list to store not booked seats
     * @return true if no seats are already booked, false otherwise
     */
    public boolean checkSeats(List<Integer> AllSeats, List<Integer> seats, List<Integer> alreadyBooked, List<Integer> notBooked) {
        for (int seat : seats) {
            if (AllSeats.contains(seat)) {
                alreadyBooked.add(seat);
            } else {
                notBooked.add(seat);
            }
        }
        return alreadyBooked.isEmpty();
    }
}
