package com.example.demo.movies.exception;

//Custom exception for when getting available seats fails
public class GetAvailableSeatsException extends RuntimeException {
 public GetAvailableSeatsException(String message) {
     super(message);
 }
}
