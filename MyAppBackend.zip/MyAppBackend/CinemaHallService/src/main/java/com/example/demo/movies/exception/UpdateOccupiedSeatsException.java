package com.example.demo.movies.exception;

//Custom exception for when updating occupied seats fails
public class UpdateOccupiedSeatsException extends RuntimeException {
 public UpdateOccupiedSeatsException(String message) {
     super(message);
 }
}


