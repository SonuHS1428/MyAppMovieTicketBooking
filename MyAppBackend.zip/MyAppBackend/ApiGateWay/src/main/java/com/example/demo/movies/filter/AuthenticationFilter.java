package com.example.demo.movies.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;

import com.example.demo.movies.util.JwtUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import org.springframework.core.io.buffer.DataBuffer;
import java.nio.charset.StandardCharsets;
 
@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {
 
    @Autowired
    private RouteValidator validator;
 
    @Autowired
    private JwtUtils util;
 
    public static class Config {
    }
 
    public AuthenticationFilter() {
        super(Config.class);
    }
 
    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
 
            if (validator.isSecured.test(exchange.getRequest())) {
                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                    return handleUnauthorized(exchange, "Missing authorization header");
                }
 
                String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    authHeader = authHeader.substring(7);
                }
                
                System.out.println(authHeader);
 
                try {
                	System.out.println("inside try");
                    String role = util.extractRolesFromToken(authHeader);
                    String requestedPath = exchange.getRequest().getPath().toString();
                    String method = exchange.getRequest().getMethod().name();
                    System.out.println(role);
                    System.out.println(isAuthorized(role, requestedPath, method));
                    if (!isAuthorized(role, requestedPath, method)) {
                    	System.out.println("inside auth checking");
                        return handleUnauthorized(exchange, "Unauthorized access");
                    }
 
                } catch (Exception e) {
                    return handleUnauthorized(exchange, "Invalid token");
                }
            }
            System.out.println("method completed");
            System.out.println(exchange.getRequest());
            return chain.filter(exchange);
        };
    }
 
    private boolean isAuthorized(String role, String path, String method) {
        // Authorization logic based on role, path, and method
        if ("ROLE_ADMIN".equalsIgnoreCase(role)) {
        	System.out.println("inside admin auth checking");
            return adminAccessPaths(path, method);
        } 
        else if ("ROLE_USER".equalsIgnoreCase(role)) {
        	System.out.println("inside role_user");
            return userAccessPaths(path, method);
        }
        return false;
    }
 
    private boolean adminAccessPaths(String path, String method) {
        return path.startsWith("/movies/addmovie") ||
               path.startsWith("/movies/update") ||
               (path.startsWith("/movies/deleteById") && method.equalsIgnoreCase("DELETE")) ||
               userAccessPaths(path, method);
    }
 
    private boolean userAccessPaths(String path, String method) {
        return path.startsWith("/movies/getAll") ||
        	   path.startsWith("/movies/getById") ||
        	   path.startsWith("/orders/api/v1/order") ||
        	   path.startsWith("/cinemahalls/api/v1/movie/update") ||
        	   path.startsWith("/cinemahalls/api/v1/movie") ||
        	   path.startsWith("/cinemahalls/api/v1/getavailableseats");
        	   
               
    }
 
    private Mono<Void> handleUnauthorized(ServerWebExchange exchange, String message) {
    	 
		ServerHttpResponse response = exchange.getResponse();
		response.setStatusCode(HttpStatus.FORBIDDEN);
		response.getHeaders().add(HttpHeaders.CONTENT_TYPE, "application/json");
 
		String jsonResponse = "{\"error\": \"" + message + "\"}";
		DataBuffer buffer = response.bufferFactory().wrap(jsonResponse.getBytes(StandardCharsets.UTF_8));
 
		return response.writeWith(Mono.just(buffer));
	}
}
