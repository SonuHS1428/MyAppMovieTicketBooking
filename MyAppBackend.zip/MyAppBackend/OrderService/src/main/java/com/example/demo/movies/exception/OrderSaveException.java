package com.example.demo.movies.exception;

public class OrderSaveException extends RuntimeException {
	public OrderSaveException(String message) {
		super(message);
	}

}
