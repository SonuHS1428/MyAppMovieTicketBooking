package com.example.demo.movies.service;

import java.util.Optional;

import org.springframework.stereotype.Service;
import com.example.demo.movies.entity.Order;
import com.example.demo.movies.exception.OrderSaveException;
import com.example.demo.movies.exception.OrderNotFoundException;
import com.example.demo.movies.repository.OrderRepository;

import lombok.extern.slf4j.Slf4j;

@Service  // Indicates that this is a service class
@Slf4j    // Provides logging support
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;

    // Constructor for dependency injection
    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    /**
     * Saves a new order.
     * 
     * @param newOrder the order to be saved
     * @return the saved order
     * @throws OrderSaveException if there is an error while saving the order
     */
    @Override
    public Order saveOrder(Order newOrder, Long userId, Long movieId) {
        try {
            newOrder.setCustomerId(userId);
            newOrder.setMovieId(movieId);
            return orderRepository.save(newOrder);
        } catch (Exception e) {
            throw new OrderSaveException("Failed to save order: " + e.getMessage());
        }
    }

    /**
     * Retrieves the last order by user ID.
     * 
     * @param userId the ID of the user
     * @return an Optional containing the last order if found, otherwise an empty Optional
     * @throws OrderNotFoundException if there is an error while retrieving the order
     */
    @Override
    public Optional<Order> getLastOrderByUserId(Long userId) {
        try {
            return orderRepository.findFirstByCustomerIdOrderByCreatedAtDesc(userId);
        } catch (Exception e) {
            throw new OrderNotFoundException("Last order not found for user: " + userId);
        }
    }
}
