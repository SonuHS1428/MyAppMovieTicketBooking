package com.example.demo.movies.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.movies.entity.Order;
import com.example.demo.movies.exception.OrderSaveException;
import com.example.demo.movies.repository.OrderRepository;

class OrderServiceTest {

    @InjectMocks
    private OrderServiceImpl orderService;

    @Mock
    private OrderRepository orderRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void saveOrder_ShouldSaveOrder_WhenValidInput() {
        Order order = new Order();
        order.setCustomerId(1L);
        order.setMovieId(1L);

        when(orderRepository.save(any(Order.class))).thenReturn(order);

        Order result = orderService.saveOrder(order, 1L, 1L);

        assertEquals(1L, result.getCustomerId());
        assertEquals(1L, result.getMovieId());
    }

    @Test
    void saveOrder_ShouldThrowOrderSaveException_WhenSaveFails() {
        Order order = new Order();
        order.setCustomerId(1L);
        order.setMovieId(1L);

        when(orderRepository.save(any(Order.class))).thenThrow(new RuntimeException("Database error"));

        assertThrows(OrderSaveException.class, () -> {
            orderService.saveOrder(order, 1L, 1L);
        });
    }

    @Test
    void getLastOrderByUserId_ShouldReturnOrder_WhenOrderExists() {
        Order order = new Order();
        order.setCustomerId(1L);

        when(orderRepository.findFirstByCustomerIdOrderByCreatedAtDesc(anyLong())).thenReturn(Optional.of(order));

        Optional<Order> result = orderService.getLastOrderByUserId(1L);

        assertEquals(1L, result.get().getCustomerId());
    }

    @Test
    void getLastOrderByUserId_ShouldReturnEmpty_WhenOrderDoesNotExist() {
        when(orderRepository.findFirstByCustomerIdOrderByCreatedAtDesc(anyLong())).thenReturn(Optional.empty());

        Optional<Order> result = orderService.getLastOrderByUserId(1L);

        assertEquals(Optional.empty(), result);
    }
}
