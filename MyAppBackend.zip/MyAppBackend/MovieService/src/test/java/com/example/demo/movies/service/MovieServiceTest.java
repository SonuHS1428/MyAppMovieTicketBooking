package com.example.demo.movies.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.movies.entity.Movies;
import com.example.demo.movies.exception.MovieNotFoundException;
import com.example.demo.movies.repository.MovieRepository;

@ExtendWith(MockitoExtension.class)
public class MovieServiceTest {

    @Mock
    private MovieRepository movieRepo;

    @InjectMocks
    private MovieServiceImpl movieService;

    private Movies movie;

    @BeforeEach
    public void setUp() {
        movie = new Movies(1, "Inception", "English", 250.0, "Evening", "image_data", Arrays.asList(1, 2, 3, 4, 5));
    }

    @Test
    public void testAddMovie() {
        when(movieRepo.save(any(Movies.class))).thenReturn(movie);
        String result = movieService.addMovie(movie);
        assertEquals("Movie Saved Successfully", result);
    }

    @Test
    public void testGetMovie() {
        when(movieRepo.findById(1)).thenReturn(Optional.of(movie));
        Movies foundMovie = movieService.getMovie(1);
        assertNotNull(foundMovie);
        assertEquals(movie.getMovieId(), foundMovie.getMovieId());
    }

    @Test
    public void testGetMovieNotFound() {
        when(movieRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(MovieNotFoundException.class, () -> {
            movieService.getMovie(1);
        });
    }

    @Test
    public void testGetAllMovies() {
        List<Movies> movieList = Arrays.asList(movie);
        when(movieRepo.findAll()).thenReturn(movieList);
        List<Movies> result = movieService.getAllMovies();
        assertEquals(1, result.size());
    }

    @Test
    public void testDeleteMovie() {
        doNothing().when(movieRepo).deleteById(1);
        String result = movieService.deleteMovie(1);
        assertEquals("Movie Deleted Successfully", result);
        verify(movieRepo).deleteById(1);
    }

    @Test
    public void testUpdateMovie() {
        when(movieRepo.save(any(Movies.class))).thenReturn(movie);
        Movies updatedMovie = movieService.updateMovie(movie);
        assertNotNull(updatedMovie);
        assertEquals(movie.getMovieId(), updatedMovie.getMovieId());
    }
}
