package com.example.demo.movies.exception;

public class GetAllMoviesException extends RuntimeException {
    public GetAllMoviesException(String message) {
        super(message);
    }
}