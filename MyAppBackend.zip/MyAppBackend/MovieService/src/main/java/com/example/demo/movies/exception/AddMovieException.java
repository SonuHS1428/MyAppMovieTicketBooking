package com.example.demo.movies.exception;

// Custom exception for when adding a movie fails
public class AddMovieException extends RuntimeException {
    public AddMovieException(String message) {
        super(message);
    }
}

