package com.example.demo.movies.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.movies.entity.Movies;
import com.example.demo.movies.exception.*;
import com.example.demo.movies.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {

    private final MovieRepository movieRepo;

    // Constructor for dependency injection
    public MovieServiceImpl(MovieRepository movieRepo) {
        this.movieRepo = movieRepo;
    }

    @Override
    public String addMovie(Movies movies) {
        try {
            Movies savedMovie = movieRepo.save(movies);
            if (savedMovie.getMovieId() != 0)  // Checks if the movie has been assigned an ID
                return "Movie Saved Successfully";  // Returns success message if movie is saved
            else
                throw new AddMovieException("Failed to save movie");
        } catch (Exception e) {
            throw new AddMovieException("Failed to save movie: " + e.getMessage());
        }
    }

    @Override
    public Movies getMovie(int movieId) throws MovieNotFoundException {
        Optional<Movies> optional = movieRepo.findById(movieId);
        return optional.orElseThrow(() -> new MovieNotFoundException("Movie not found with ID: " + movieId));  // Throws exception if movie is not found
    }

    @Override
    public List<Movies> getAllMovies() {
        try {
            return movieRepo.findAll();  // Returns a list of all movies
        } catch (Exception e) {
            throw new GetAllMoviesException("Failed to get all movies: " + e.getMessage());
        }
    }

    @Override
    public String deleteMovie(int movieId) {
        try {
            movieRepo.deleteById(movieId);
            return "Movie Deleted Successfully";  // Returns success message if movie is deleted
        } catch (Exception e) {
            throw new DeleteMovieException("Failed to delete movie: " + e.getMessage());
        }
    }

    @Override
    public Movies updateMovie(Movies movies) {
        try {
            Movies updatedMovie = movieRepo.save(movies);
            if (updatedMovie.getMovieId() != 0)  // Checks if the movie has been assigned an ID
                return updatedMovie;  // Returns the updated movie
            else
                throw new UpdateMovieException("Failed to update movie");
        } catch (Exception e) {
            throw new UpdateMovieException("Failed to update movie: " + e.getMessage());
        }
    }
}
