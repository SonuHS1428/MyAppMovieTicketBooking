package com.example.demo.movies.exception;

// Custom exception for when updating a movie fails
public class UpdateMovieException extends RuntimeException {
    public UpdateMovieException(String message) {
        super(message);
    }
}


