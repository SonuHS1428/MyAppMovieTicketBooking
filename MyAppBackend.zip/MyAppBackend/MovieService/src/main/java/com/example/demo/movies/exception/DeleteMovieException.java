package com.example.demo.movies.exception;

//Custom exception for when deleting a movie fails
public class DeleteMovieException extends RuntimeException {
 public DeleteMovieException(String message) {
     super(message);
 }
}


